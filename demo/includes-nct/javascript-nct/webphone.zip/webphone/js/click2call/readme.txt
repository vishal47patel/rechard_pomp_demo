JavaScript files for the click-to-call skin (click2call.html).
You might edit these files to further customize the softphone skin if the webphone parameter are not enough or doesn't cover your needs.
This is just a simple example for click-to-call implementation and you might create your click to call button from scratch if you wish.


