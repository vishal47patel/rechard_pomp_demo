JavaScript files for the softphone skin (softphone.html).
You might edit these files to further customize the softphone skin if the webphone parameter are not enough or doesn't cover your needs.


