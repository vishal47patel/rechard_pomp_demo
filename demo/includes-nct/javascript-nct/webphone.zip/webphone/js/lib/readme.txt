JavaScript files for the webphone library.
These are the most important files for the webphone.
Changes in these files are not recommended, as it requires deep understanding of the webphone internals and VoIP/SIP/WebRTC technologies. 
The webphone is compatible with all the popular browsers and also with most outdated/old browsers and it should work also with future browser releases.
The webphone library is actively maintained by MizuTech with new upgrades published periodically with bug fixes, improvements and new features.

