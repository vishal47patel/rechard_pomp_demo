Software name: Webphone
Version: 3.4
Developer: Mizutech
Web: https://www.mizu-voip.com/Software/WebPhone.aspx
Documentation: https://www.mizu-voip.com/Portals/0/Files/Webphone_Documentation.pdf
Contact: webphone@mizu-voip.com

See the html examples and the documentation for the usage.
